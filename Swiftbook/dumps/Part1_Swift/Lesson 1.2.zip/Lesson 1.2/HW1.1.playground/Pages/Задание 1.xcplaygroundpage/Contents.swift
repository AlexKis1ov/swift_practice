
import Foundation

/*:
 # Home Work 1
 
 ## Задание 1
 
 Объявите константу `firstString` со значением "I can" и `secondString` со значением "code". В значенях констант ни каких хитростей с лишними пробелами быть не должно. Выведите на консоль фразу **"I can code!"** с восклицательным знаком, используя эти строковые свойства.
 */

let firstString = "I can"
let secondString = "code"

print(firstString + " " + secondString + "!")
print("\(firstString) \(secondString)!")

//: Задание 1 из 3  |  [Далее: Задание 2](@next)
